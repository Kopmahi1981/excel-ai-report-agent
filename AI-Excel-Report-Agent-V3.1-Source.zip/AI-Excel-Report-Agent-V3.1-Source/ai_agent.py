import google.generativeai as genai

# Paste your NEW Gemini API key here
genai.configure(api_key="AQ.Ab8RN6It0a5PD8FVl5JsMm_6bVkZe965Y_yAPYXfNLAaqVHrTw")

model = genai.GenerativeModel("gemini-2.5-flash")


def generate_ai_report(df):

    try:

        sample_data = df.head(20).to_string()

        prompt = f"""
        Analyze this investment dataset.

        Provide:
        1. Executive Summary
        2. Key Trends
        3. Important Insights
        4. Business Recommendations

        Dataset:
        {sample_data}
        """

        response = model.generate_content(prompt)

        return response.text

    except Exception as e:

        return str(e)