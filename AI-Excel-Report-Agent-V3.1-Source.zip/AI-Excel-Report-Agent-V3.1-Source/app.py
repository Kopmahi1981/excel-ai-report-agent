import streamlit as st
import pandas as pd
import plotly.express as px
from analyzer import analyze_data
from ai_agent import generate_ai_report
from exporter import create_pdf_report

st.set_page_config(page_title="AI Excel Report Agent", layout="wide")

st.title("📊 AI Excel Report Agent")

uploaded_file = st.file_uploader(
    "Upload your Excel File",
    type=["xlsx", "xls", "csv"]
)

if uploaded_file:

    if uploaded_file.name.endswith(".csv"):
        df = pd.read_csv(uploaded_file)

    else:
        df = pd.read_excel(uploaded_file)

    # Fix one-column Excel files
    if len(df.columns) == 1:

        df = df[df.columns[0]].str.split(",", expand=True)

        df.columns = [
            "Investor Name",
            "PAN Number",
            "City",
            "Investment Type",
            "Investment Amount",
            "Annual Return %"
        ]

        df["Investment Amount"] = pd.to_numeric(
            df["Investment Amount"],
            errors="coerce"
        )

        df["Annual Return %"] = pd.to_numeric(
            df["Annual Return %"],
            errors="coerce"
        )
    st.success("File uploaded successfully!")

    st.subheader("📄 Data Preview")
    st.dataframe(df.head())

    st.subheader("📌 Dataset Information")
    st.write(df.describe())

    numeric_columns = df.select_dtypes(include=['number']).columns

    if len(numeric_columns) > 0:

        selected_column = st.selectbox(
            "Select Column for Chart",
            numeric_columns
        )
        fig = px.histogram(
            df,
            x=selected_column,
            title=f"{selected_column} Distribution"
        )

        bar_fig = px.bar(
        df.head(10),
        x="Investor Name",
        y="Investment Amount",
        title="Top Investment Amounts"
        )
        pie_fig = px.pie(
        df,
        names="Investment Type",
        values="Investment Amount",
        title="Investment Type Distribution"
        )
        pie_fig.write_image("piechart.png")
        bar_fig.write_image("barchart.png")
        fig.write_image("chart.png")

        st.plotly_chart(fig, use_container_width=True)

    if st.button("Generate AI Report"):

        with st.spinner("Analyzing data with AI..."):

            basic_analysis = analyze_data(df)

            ai_report = generate_ai_report(df)

            st.subheader("🤖 AI Business Insights")

            cleaned_df = df.copy()

            # Remove duplicates
            cleaned_df = cleaned_df.drop_duplicates()

            # Fill missing numeric values with median
            for col in cleaned_df.select_dtypes(include="number").columns:
                cleaned_df[col] = cleaned_df[col].fillna(
                    cleaned_df[col].median()
                )

            # Fill missing text values with "Unknown"
            for col in cleaned_df.select_dtypes(include="object").columns:
                cleaned_df[col] = cleaned_df[col].fillna(
                    "Unknown"
                )

                duplicates_found = df.duplicated().sum()

                duplicates_removed = duplicates_found

                missing_before = df.isnull().sum().sum()

                missing_after = cleaned_df.isnull().sum().sum()

                missing_fixed = missing_before - missing_after

                st.write("DEBUG CHECKPOINT")

                st.subheader("🧹 Data Cleaning Audit")

                st.write("Duplicates Found:", duplicates_found)

                st.write("Duplicates Removed:", duplicates_removed)

                st.write("Missing Values Found:", missing_before)

                st.write("Missing Values Fixed:", missing_fixed)

                st.write("Remaining Missing Values:", missing_after)

                st.success("Dataset Cleaned Successfully")

            pdf_file = create_pdf_report(
                ai_report,
                rows=df.shape[0],
                columns=df.shape[1],
                missing_values=df.isnull().sum().sum(),
                column_names=df.columns.tolist(),
                statistics=df.describe().to_dict(),
                duplicate_rows=df.duplicated().sum(),
                average_investment=df["Investment Amount"].mean(),
                highest_investment=df["Investment Amount"].max(),
                lowest_investment=df["Investment Amount"].min()
            )

        with open("cleaned_dataset.xlsx", "rb") as file:
            st.download_button(
                label="📥 Download Cleaned Dataset",
                data=file,
                file_name="cleaned_dataset.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )

        with open(pdf_file, "rb") as file:
            st.download_button(
                label="📄 Download PDF Report",
                data=file,
                file_name="AI_Report.pdf",
                mime="application/pdf"
            )

        st.subheader("📈 Basic Analysis")
        st.write(basic_analysis)